function myFunction(){
    setInterval(function(){alert("Game Over");}, 2000);
    }
